var browser_api = typeof browser == "undefined" ? chrome : browser;

var port = browser_api.runtime.connect({ name: "port-from-cs" });

document.addEventListener('addon', function (event) {
    port.postMessage(event.detail);
});
port.onMessage.addListener(function (reply) {
    var event = new CustomEvent('addon_reply', { detail: JSON.stringify(reply) });
    document.dispatchEvent(event)
});